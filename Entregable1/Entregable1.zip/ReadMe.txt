- El ejercicio 1 es el archivo "DiagramaDeArchivos.drawio.png".
	- Los metodos abstractos presentan formato italics (cursiva) y los atributos y los metodos estáticos se encuentran subrayados.

- El ejercicio 2 presenta el diagrama de secuencia, junto a una breve descripción de lo que modela, en el archivo "DiagramaDeSecuencia.drawio.png". Asimismo, el PseudoCodigo se encuentra en el archivo "PseudoCodigo.txt".

- Los ejercicios 3 y 4 se encuentran resueltos dentro de la carpeta "Entregable1", donde se encontrará el codigo hecho en Eclipse en la carpeta "src" y la resolucion del Javadoc en la carpeta "doc".