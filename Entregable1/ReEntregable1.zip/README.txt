Se incluyeron las siguientes mejoras en el diagrama de clases:

-Los campos de fecha son de tipo DateTime.

-"Usuario" conoce su "Seguridad" y a su "Billetera".

-Se modelo al pais como un tipo enumerativo, para el cual se agregaron algunas posibles opciones, y además se lo extendió a que tambien pueda ser una región.

-"Usuario" conoce no solo su reporte de Altas y Bajas, sino que todos sus reportes.

-"ReporteDeTransacciones" pasa a llamarse "Transaccion" y ahora "ReportesFinancieros" contiene una lista de "transacciones".

-Se modelo el campo "estado" de algunas clases y el campo "estadoDeBaja" como un tipo enumerativo con algunas opciones.

-Atributos como fiatElegido en Billetera, cripto en TasaDeCambio, moneda en ReporteDeDeFi, moneda en Protocolo se representaron como relaciones.